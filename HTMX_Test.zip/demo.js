const express=require("express");
// const ejs=require("ejs")
const app=express();
const path=require("path");
app.use(express.static('./views'));
const port=3000;
app.set("view engine","ejs");
// app.set("views",path.resolve("./views"));
app.get('/',(req,res)=>
{
    return res.render("index");
})
app.get('/about',(req,res)=>
{
    return res.render("about");
})
app.listen(3000,()=>{console.log("Iam in port 3000")});
