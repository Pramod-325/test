document.addEventListener("DOMContentLoaded", function() {
const myTimeout = setTimeout(test, 1000);
  test();
});
const b1 = document.getElementById("b1");
const b2 = document.getElementById("b2");
function test(){
  b1.click();
}