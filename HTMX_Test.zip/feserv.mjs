import express from "express"

const port = 5030
const app = express()

app.use(express.static('public'));
app.get("/cdiv",(req,res)=>{

res.status(200).send(`Oh my God, I'm your'e a pro in HTMX &#128526;`);
console.log(`------------------------- Button B1 pressed ${counter}`);
//console.log(req.headers)

})

app.get("/register",(req,res)=>{
res.status(200).send("Back to Normal");
//console.log("------------------------- Button B2 pressed")
//console.log(req.header)
})


app.listen(port,()=>{
console.log(`server listening on port: ${port}`);
})